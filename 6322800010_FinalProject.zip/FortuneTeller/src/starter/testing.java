package starter;

public class testing extends main{

	public static void main(String[] args) {
		main p = new testing();
				new testing();
				
		
		
		
	}
}
