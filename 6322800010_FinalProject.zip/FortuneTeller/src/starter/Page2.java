package starter;


import javax.swing.*;

import fortunecategories.category1;
import fortunecategories.category10;
import fortunecategories.category11;
import fortunecategories.category12;
import fortunecategories.category2;
import fortunecategories.category3;
import fortunecategories.category4;
import fortunecategories.category5;
import fortunecategories.category6;
import fortunecategories.category7;
import fortunecategories.category8;
import fortunecategories.category9;

import java.awt.*;
import java.awt.event.*;
public class Page2 extends main implements ActionListener, KeyListener, ItemListener{
	int i =1;
	JFrame frame = new JFrame("Fortune Teller");
	JLabel typein = new JLabel("Plese fill in your birthdate");
	JLabel d = new JLabel("Date/ ");
	JLabel m = new JLabel("Month/ ");
	JLabel y = new JLabel("Year/ ");
	JLabel name = new JLabel("Type in your Name&Lastname");
	JLabel image = new JLabel();
	
	private JPanel namelast = new JPanel();
	JPanel type = new JPanel();
	JPanel dmy = new JPanel();
	JPanel mo = new JPanel();
	JPanel ye = new JPanel();
	JPanel submit = new JPanel();
	JPanel allbutton = new JPanel();
    JComboBox date = new JComboBox();	
	JComboBox month = new JComboBox();
	JComboBox year = new JComboBox();

	
	JTextField namelastname = new JTextField(10);
	JButton sub = new JButton("Submit");
	JButton can = new JButton("Back");
	Timer timer = new Timer(500,this);

	public Page2() {
		
		timer.start();
		frame.setLayout(new BorderLayout());
		frame.setContentPane(new JLabel(new ImageIcon("C:\\\\Users\\\\Win10\\\\Pictures\\\\18d0b9efe68339f4eba576b7738aa136.png")));
		frame.add(image);
		image.setBounds(0,0,1000,500);

		
		type.setBounds(200,80,600,150);
		type.setOpaque(false);
		typein.setForeground(Color.yellow);
		typein.setFont(new Font("Times New Roman",Font.PLAIN,50));
		type.add(typein);
		
		
		dmy.setLayout(new FlowLayout());
		dmy.setSize(500,300);
		dmy.setBounds(200,200,600,150);
		dmy.setOpaque(false);
		d.setForeground(Color.yellow);
		m.setForeground(Color.yellow);
		y.setForeground(Color.yellow);
		d.setFont(new Font("Times New Roman",Font.PLAIN,50));
		m.setFont(new Font("Times New Roman",Font.PLAIN,50));
		y.setFont(new Font("Times New Roman",Font.PLAIN,50));
		dmy.add(d); dmy.add(m); dmy.add(y);
		
		
		month.addItem("January"); month.addItem("February"); month.addItem("March"); month.addItem("April"); month.addItem("May");
		month.addItem("June"); month.addItem("July"); month.addItem("August"); month.addItem("September"); month.addItem("October");
		month.addItem("November"); month.addItem("December");
		mo.setBounds(410,300,150,50);
		mo.setOpaque(false);
		mo.add(month);
		
		for(int i=1950; i <=2021; i++)
		{
			year.addItem(i);
		}
		
		ye.setBounds(550,300,150,50);
		ye.setOpaque(false);
		ye.add(year);
		
		
		
		
		for(int i=1; i<=31;i++)
		{
			date.addItem(i);
		}

		allbutton.setBounds(270,300,150,50);
		allbutton.setOpaque(false);
		allbutton.add(date); 

		
		submit.setLayout(new FlowLayout()); 
		submit.setBounds(420,500,150,50);
		submit.add(sub);submit.add(can);
		submit.setOpaque(false);
		
		namelast.setLayout(new FlowLayout());
		namelast.setBounds(200,350,600,150);
		namelast.setOpaque(false);
		name.setForeground(Color.yellow);
		name.setFont(new Font("Times New Roman",Font.PLAIN,40));
		namelast.add(name); namelast.add(namelastname);
		namelast.addKeyListener(this);
		
		
		frame.add(allbutton);
		frame.add(type);
		frame.add(dmy);
		frame.add(mo);
		frame.add(ye);
		frame.add(submit);
		frame.add(namelast);
		
		
		
		sub.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {

		if(date.getSelectedIndex() >= 21  && month.getSelectedItem() == "March" || date.getSelectedIndex() <=19 && month.getSelectedItem() == "April") {
					
				frame.dispose();
				new category1();
				timer.stop();}
		else if (date.getSelectedIndex() >= 20  && month.getSelectedItem() == "April" || date.getSelectedIndex() <=20 && month.getSelectedItem() == "May") {
				frame.dispose();
				new category2();
				timer.stop();}
		else if(date.getSelectedIndex() >= 21  && month.getSelectedItem() == "May" || date.getSelectedIndex() <=20 && month.getSelectedItem() == "June") {
			frame.dispose();
			new category3();
			timer.stop();}
		else if(date.getSelectedIndex() >= 21  && month.getSelectedItem() == "June" || date.getSelectedIndex() <=22 && month.getSelectedItem() == "July") {
			frame.dispose();
			new category4();
			timer.stop();}
		else if(date.getSelectedIndex() >= 23  && month.getSelectedItem() == "July" || date.getSelectedIndex() <=22 && month.getSelectedItem() == "August") {
			frame.dispose();
			new category5();
			timer.stop();}
		else if(date.getSelectedIndex() >= 23  && month.getSelectedItem() == "August" || date.getSelectedIndex() <=22 && month.getSelectedItem() == "September") {
			frame.dispose();
			new category6();
			timer.stop();}
		else if(date.getSelectedIndex() >= 23  && month.getSelectedItem() == "September" || date.getSelectedIndex() <=20 && month.getSelectedItem() == "October") {
			frame.dispose();
			new category7();
			timer.stop();}
		else if(date.getSelectedIndex() >= 23  && month.getSelectedItem() == "October" || date.getSelectedIndex() <=21 && month.getSelectedItem() == "November") {
			frame.dispose();
			new category8();
			timer.stop();}
		else if(date.getSelectedIndex() >= 22  && month.getSelectedItem() == "November" || date.getSelectedIndex() <=21 && month.getSelectedItem() == "December") {
			frame.dispose();
			new category9();
			timer.stop();}
		else if(date.getSelectedIndex() >= 22  && month.getSelectedItem() == "December" || date.getSelectedIndex() <=19 && month.getSelectedItem() == "January") {
			frame.dispose();
			new category10();}
		else if(date.getSelectedIndex() >= 20  && month.getSelectedItem() == "January" || date.getSelectedIndex() <=18 && month.getSelectedItem() == "February") {
			frame.dispose();
			new category11();
			timer.stop();}
		else if(date.getSelectedIndex() >= 19  && month.getSelectedItem() == "February" || date.getSelectedIndex() <=20 && month.getSelectedItem() == "March") {
			frame.dispose();
			new category12();
			timer.stop();}
		
		}
		});
		
		can.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				frame.dispose();
				new main();
			}
		});
		
		
	
		
		
		
		namelastname.addKeyListener(new KeyAdapter() {
			 public void keyPressed(KeyEvent e) {
		            char ch = e.getKeyChar();
		            if(Character.isDigit(ch)){
		                namelastname.setText("");
		                JOptionPane.showMessageDialog(null, "Enter Alphabet Only !");
		                repaint();
			}}
		});
		
		
		
		
		
		date.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
                if (date.getSelectedIndex() !=  ItemEvent.SELECTED) {
                	JOptionPane.showMessageDialog(null, "Nice date");
                	
                }
            }
        });
		
		
		
		
		
		
		frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		frame.setSize(1000,600);
		frame.setVisible(true);
		
		
		
	}
	
	
	

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		repaint();
		}



	

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		char ch = e.getKeyChar();
        if(Character.isDigit(ch)){
            namelastname.setText("");
            JOptionPane.showMessageDialog(null, "Enter Alphabet Only !");
            repaint();
        }
	}



	



	@Override
	public void itemStateChanged(ItemEvent e) {
		
         
	}




	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}




	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
		
}
	
	

	






