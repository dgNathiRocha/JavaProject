package starter;
import javax.swing.*; import java.awt.*; import java.awt.event.*;
public class main extends JFrame implements ActionListener {

	Timer timer = new Timer(500,this);
	JButton start = new JButton("Yes");
	JButton quit = new JButton("No");
	JPanel p1 = new JPanel();
	JPanel titlepanel = new JPanel();
	JPanel quespanel = new JPanel();
	JLabel title = new JLabel("FORTUNE TELLER");
	JLabel image = new JLabel();
	JLabel question = new JLabel("Would you like to know your luck?");
	
	
	public main() {
		timer.start();
		
		JFrame frame = new JFrame("Fortune Teller");
		frame.setLayout(new BorderLayout());
		
		frame.setContentPane(new JLabel(new ImageIcon("C:\\Users\\Win10\\Pictures\\18d0b9efe68339f4eba576b7738aa136.png")));
		frame.add(image);
		image.setBounds(0,0,1000,500);
		
		titlepanel.setBounds(200,80,600,150);
		titlepanel.setOpaque(false);
		title.setForeground(Color.yellow);
		title.setFont(new Font("Times New Roman",Font.PLAIN,50));
		titlepanel.add(title);
		
		quespanel.setBounds(200,180,600,150);
		quespanel.setOpaque(false);
		question.setForeground(Color.yellow);
		question.setFont(new Font("Times New Roman",Font.PLAIN,25));
		quespanel.add(question);
		
		
		frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		frame.add(start); frame.add(quit);
		
		p1.setLayout(new FlowLayout()); 
		p1.setBounds(420,400,150,50);
		p1.add(start);p1.add(quit);
		p1.setOpaque(false);
		
		frame.add(p1,BorderLayout.SOUTH);
		
		start.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				frame.dispose();
				new Page2();
				
			}
		});
		
		quit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				frame.dispose();
				System.exit(0);
				timer.stop();
			}
		});
		frame.setSize(1000,600);
		frame.setVisible(true);
		
		
		frame.add(titlepanel); frame.add(quespanel);
		
	}


	

public void actionPerformed(ActionEvent ae) {
	// TODO Auto-generated method stub
	repaint();
}






}