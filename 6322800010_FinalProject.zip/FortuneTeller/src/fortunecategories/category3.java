package fortunecategories;
import starter.Page2;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class category3 extends Page2 implements ActionListener{
	
	JFrame frame = new JFrame("Fortune Teller");
	JPanel txt = new JPanel();
	JPanel paint = new JPanel();
	JTextArea txtarea = new JTextArea(
			 "Daily Love\n"
			+ "The moon will join forces with audacious Mars via your stability-seeking second house of comfort, finances, and value systems�emotionally binding you to themes surrounding financial matters and, more importantly, your sense of security. And despite whether you're single or taken, today's transformative trine will light up your twelfth house of unconscious patterns, and your intimate eighth house of soul ties, shedding light on everything from residual energies that are no longer serving your highest good, to the parts of you that lack compassion. You're healing, Gemini. The good news is, both Mercury and Venus are working in your favor, so find the right choice of words.\r\n"
					 +
					 "Daily Work\n"+
"Hidden information can reveal itself today, but ultimately it�s likely to benefit you when it comes to work, dear Gemini. Perhaps there is more room in your budget that you did not foresee, or maybe you�ve underestimated your spending. With this newfound resource, it can feel like a weight off of your shoulders. The abundant Taurus moon is in your twelfth house and coming to light with its connection to powerful Pluto in Capricorn in your financial sector. Make the best use of this extra dose of material help.");
			
			
	
	
	public category3() {
		Timer timer = new Timer(500,this);
		timer.start();
	frame.setLayout(new BorderLayout());
	frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	frame.setSize(1000,600);
	frame.setVisible(true);
	
	txt.setBackground(Color.black);
	txt.setBounds(00,100,100,500);

	
	txtarea.setBounds(400,50,400,600);
	txtarea.setBackground(Color.black);
	txtarea.setForeground(Color.white);
	txtarea.setFont(new Font("Times New Roman",Font.PLAIN,17));
	txtarea.setLineWrap(true);
	txtarea.setWrapStyleWord(true);
	
	txt.add(txtarea);
	
	frame.add(txt, BorderLayout.EAST);
	

	

	frame.add(new heart(), BorderLayout.CENTER);
	JButton back = new JButton("BACK");
	paint.setBounds(200,500,200,300);
	paint.setOpaque(false);
	paint.add(back);
	frame.add(paint, BorderLayout.SOUTH);
	
	back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				frame.dispose();
				new Page2();
				
			}
		});	
	
	
	
	
	
	
	
	
	
	
	}
	
}
