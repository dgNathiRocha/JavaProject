package fortunecategories;
import starter.Page2;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class category8 extends Page2 implements ActionListener{
	
	JFrame frame = new JFrame("Fortune Teller");
	JPanel txt = new JPanel();
	JPanel paint = new JPanel();
	JTextArea txtarea = new JTextArea(
			 "Daily Love\n"
			+ "Is it time for the talk, Scorpio? Today's transformative trine between the sun in your committed seventh house of one-on-one relationships and smoldering planetary ruler, Pluto, via your chatty third house of communication, creates a powerful synergy that could potentially trigger a highly anticipated conversation. And with the moon lingering over your expansive ninth house of experience, philosophy, and unknown territory, a part of you could be longing for a new beginning. Sounds grim but your relationships are making it or breaking it. So, if something feels out of place or it�s unstable, perhaps this is your official sign from the cosmos to let it go.\r\n"
					 +
					 "Daily Work\n"+
"Travel for work may be a theme of the day for many Scorpios. There is a lot of action occurring in your ninth house of international relations and long-distance travel. The Cancer moon is forming a connection with Mars, the planet of drive. It�s also activating otherworldly Jupiter in Pisces in your fifth house of creative projects. This can expand your experience, teach you something new in a major way.");
			
			
	
	
	public category8() {
		Timer timer = new Timer(500,this);
		timer.start();
	frame.setLayout(new BorderLayout());
	frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	frame.setSize(1000,600);
	frame.setVisible(true);
	
	txt.setBackground(Color.black);
	txt.setBounds(00,100,100,500);

	
	txtarea.setBounds(400,50,400,600);
	txtarea.setBackground(Color.black);
	txtarea.setForeground(Color.white);
	txtarea.setFont(new Font("Times New Roman",Font.PLAIN,17));
	txtarea.setLineWrap(true);
	txtarea.setWrapStyleWord(true);
	
	txt.add(txtarea);
	
	frame.add(txt, BorderLayout.EAST);
	


	frame.add(new heart(), BorderLayout.CENTER);
	JButton back = new JButton("BACK");
	paint.setBounds(200,500,200,300);
	paint.setOpaque(false);
	paint.add(back);
	frame.add(paint, BorderLayout.SOUTH);
	
	back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				frame.dispose();
				new Page2();
				
			}
		});	
	

	
	
	
	
	
	
	
	
	
	
	
	}
	
}
