package fortunecategories;
import starter.Page2;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class category9 extends Page2 implements ActionListener{
	
	JFrame frame = new JFrame("Fortune Teller");
	JPanel txt = new JPanel();
	JPanel paint = new JPanel();
	JTextArea txtarea = new JTextArea(
			 "Daily Love\n"
			+ "Are they *really* worth your precious energy, Sagittarius? The moon continues to travel alongside red-hot Mars via your sultry eighth house of intimacy, mergers, energetic exchanges, and soulmate connections�heightening everything from your sexual libido to the desire to fully merge with another mind, body, and soul. Meanwhile, today's transformative trine between the sun in your sixth house of divine duties and smoldering Pluto via your stability-seeking second house of value systems presents you with a tremendous amount of drive and intensity. This will also shed light on the people, places, and things that aren't worthy of your energy.\r\n"
					 +
					 "Daily Work\n"+
"Sagittarius, this is an optimal day to have important conversations, and discuss the details of a project with collaborators. Communication is flowing easily, and others are more receptive to your ideas. This is due to harmonious Venus forming a conjunction with the karmic North Node in your seventh house of work relationships. Use this time to sign new contracts, agree to work with others, and embrace the support you can receive from collaborations.");
			
			
	
	
	public category9() {
		Timer timer = new Timer(500,this);
		timer.start();
	frame.setLayout(new BorderLayout());
	frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	frame.setSize(1000,600);
	frame.setVisible(true);
	
	txt.setBackground(Color.black);
	txt.setBounds(00,100,100,500);

	
	txtarea.setBounds(400,50,400,600);
	txtarea.setBackground(Color.black);
	txtarea.setForeground(Color.white);
	txtarea.setFont(new Font("Times New Roman",Font.PLAIN,17));
	txtarea.setLineWrap(true);
	txtarea.setWrapStyleWord(true);
	
	txt.add(txtarea);
	
	frame.add(txt, BorderLayout.EAST);
	


	frame.add(new heart(), BorderLayout.CENTER);
	JButton back = new JButton("BACK");
	paint.setBounds(200,500,200,300);
	paint.setOpaque(false);
	paint.add(back);
	frame.add(paint, BorderLayout.SOUTH);
	
	back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				frame.dispose();
				new Page2();
				
			}
		});	
	

	
	
	
	
	
	
	
	
	
	
	
	}
	
}
