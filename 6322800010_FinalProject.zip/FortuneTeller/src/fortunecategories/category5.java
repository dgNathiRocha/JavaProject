package fortunecategories;
import starter.Page2;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class category5 extends Page2 implements ActionListener{
	
	JFrame frame = new JFrame("Fortune Teller");
	JPanel txt = new JPanel();
	JPanel paint = new JPanel();
	JTextArea txtarea = new JTextArea(
			 "Daily Love\n"
			+ "Whether we're single or already taken, today's astro weather is encouraging you to create a healthy balance between your personal and professional life. This is especially true with your majestic planetary ruler, the sun, activating your bossy tenth house of career while making a trine to powerhouse Pluto via your responsible sixth house of due diligence. Are your daily duties getting in the way of the quality time you spend with your lover? For some of you, this astrological aspect will propel you forward in your career, despite whether your cutie's on board. Again, this is a highly transformative time, so your best bet is to go with the flow, Leo.\r\n"
					 +
					 "Daily Work\n"+
"Your creativity is extremely potent right now, dear Lion. The cosmos ask you to express yourself. The Taurus sun is shining bright in its final degrees in your tenth house of career and professional status. It�s forming an empowering aspect with Pluto retrograde in Capricorn in your sixth house of duty. Many Leos have been putting in a lot of work behind the scenes, and with this positive aspect, the fruits of their labor can finally manifest. You deserve it!");
			
			
	
	
	public category5() {
		Timer timer = new Timer(500,this);
		timer.start();
	frame.setLayout(new BorderLayout());
	frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	frame.setSize(1000,600);
	frame.setVisible(true);
	
	txt.setBackground(Color.black);
	txt.setBounds(00,100,100,500);

	
	txtarea.setBounds(400,50,400,600);
	txtarea.setBackground(Color.black);
	txtarea.setForeground(Color.white);
	txtarea.setFont(new Font("Times New Roman",Font.PLAIN,17));
	txtarea.setLineWrap(true);
	txtarea.setWrapStyleWord(true);
	
	txt.add(txtarea);
	
	frame.add(txt, BorderLayout.EAST);
	


	frame.add(new heart(), BorderLayout.CENTER);
	JButton back = new JButton("BACK");
	paint.setBounds(200,500,200,300);
	paint.setOpaque(false);
	paint.add(back);
	frame.add(paint, BorderLayout.SOUTH);
	
	back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				frame.dispose();
				new Page2();
				
			}
		});	

	
	
	
	
	
	
	
	
	
	
	
	}
	
}
