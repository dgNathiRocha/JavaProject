package fortunecategories;
import starter.Page2;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class category7 extends Page2 implements ActionListener{
	
	JFrame frame = new JFrame("Fortune Teller");
	JPanel txt = new JPanel();
	JPanel paint = new JPanel();
	JTextArea txtarea = new JTextArea(
			 "Daily Love\n"
			+ "The moon continues to travel alongside sizzling Mars�celestial ruler of your committed seventh house of agreements, one-on-one relationships, and significant others�igniting the fire in your relationship sector. But by that same token, this could create friction between you and your lover. It's important to also reflect on your emotional truth and whether you feel comfortable expressing it, Libra. Today's trine between the sun in your erotic eighth house of intimacy and powerhouse Pluto in your domestic fourth house of home can be equally empowering as it is cathartic. Single? Be mindful of what you're projecting; you're healing and that takes time.\r\n"
					 +
					 "Daily Work\n"+
"Libra, your schedule is filling up and it�s important to know your boundaries with work commitments. The planetary energy can leave you feeling as if you have to take on each task that is assigned to you. It�s important to strategize and to set reasonable priorities and deadlines for yourself. This intense influx of duties is being brought on by abundant Venus and Jupiter forming a square. An aspect like this can cause an increase in work, but know that it�s passing and will die down.");
			
			
	
	
	public category7() {
		Timer timer = new Timer(500,this);
		timer.start();
	frame.setLayout(new BorderLayout());
	frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	frame.setSize(1000,600);
	frame.setVisible(true);
	
	txt.setBackground(Color.black);
	txt.setBounds(00,100,100,500);

	
	txtarea.setBounds(400,50,400,600);
	txtarea.setBackground(Color.black);
	txtarea.setForeground(Color.white);
	txtarea.setFont(new Font("Times New Roman",Font.PLAIN,17));
	txtarea.setLineWrap(true);
	txtarea.setWrapStyleWord(true);
	
	txt.add(txtarea);
	
	frame.add(txt, BorderLayout.EAST);
	

	
	
	
	
	

	frame.add(new heart(), BorderLayout.CENTER);
	JButton back = new JButton("BACK");
	paint.setBounds(200,500,200,300);
	paint.setOpaque(false);
	paint.add(back);
	frame.add(paint, BorderLayout.SOUTH);
	
	back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				frame.dispose();
				new Page2();
				
			}
		});	
	
	
	
	
	
	
	}
	
}
