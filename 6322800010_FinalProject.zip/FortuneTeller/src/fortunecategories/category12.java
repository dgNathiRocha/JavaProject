package fortunecategories;
import starter.Page2;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class category12 extends Page2 implements ActionListener{
	
	JFrame frame = new JFrame("Fortune Teller");
	JPanel txt = new JPanel();
	JPanel paint = new JPanel();
	JTextArea txtarea = new JTextArea(
			 "Daily Love\n"
			+ "Follow your heart, Pisces. With the moon sitting together with red-hot Mars via your flirtatious fifth house of love, passion, and pleasure, chances are you're burning with lust and romantic desire. But it doesn't end there. There will be a powerful trine between the sun in your communication sector, and smoldering Pluto via your eleventh house of associations today, bringing forth the opportunity to make pivotal connections and/or gain important insight. Keep in mind, Plutonian energy brings catharsis, rebirth, and much needed tower moments, so pay attention to the events that transpire during this time. You could very well learn something new about a lover or a potential prospect.\r\n"
					 +
					 "Daily Work\n"+
"Pisces, some setbacks regarding money can occur for you today, leaving you feeling some inner tension about your self-worth. This could be through clients underrating your work, or you feeling as though you are not being compensated enough for your work. This is due to Mars in its debility, forming a difficult aspect with Chiron in Aries in your money sector. Navigate this energy by taking inventory of what you bring to the work table. Create strategic conversations with important colleagues  to bring change.");
			
			
	
	
	public category12() {
		Timer timer = new Timer(500,this);
		timer.start();
	frame.setLayout(new BorderLayout());
	frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	frame.setSize(1000,600);
	frame.setVisible(true);
	
	txt.setBackground(Color.black);
	txt.setBounds(00,100,100,500);

	
	txtarea.setBounds(400,50,400,600);
	txtarea.setBackground(Color.black);
	txtarea.setForeground(Color.white);
	txtarea.setFont(new Font("Times New Roman",Font.PLAIN,17));
	txtarea.setLineWrap(true);
	txtarea.setWrapStyleWord(true);
	
	txt.add(txtarea);
	
	frame.add(txt, BorderLayout.EAST);
	


	frame.add(new heart(), BorderLayout.CENTER);
	JButton back = new JButton("BACK");
	paint.setBounds(200,500,200,300);
	paint.setOpaque(false);
	paint.add(back);
	frame.add(paint, BorderLayout.SOUTH);
	
	back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				frame.dispose();
				new Page2();
				
			}
		});	
	
	
	
	
	
	
	
	
	}
	
}
