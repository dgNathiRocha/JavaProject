package fortunecategories;
import starter.Page2;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class category4 extends Page2 implements ActionListener{
	
	JFrame frame = new JFrame("Fortune Teller");
	JPanel txt = new JPanel();
	JPanel paint = new JPanel();
	JTextArea txtarea = new JTextArea(
			 "Daily Love\n"
			+ "The way you relate to others, and vice versa is changing, but you already knew that, Cancer. Powerful connections are bound to take place today, despite whether you're single or taken. This, of course, is all thanks to the transformative trine happening between the sun in your socially conscious eleventh house of networks, and powerhouse Pluto via your committed seventh house of relationships. What are you afraid of? The only way out is through. The moon continues to ignite your cardinal waters, alongside sizzling Mars, heightening everything from your emotions to your red-hot passions. Enjoy the day, and the energy headed your way.\r\n"
					 +
					 "Daily Work\n"+
"Cancer, taking time today to focus on self-care and restoration can be extremely helpful to your work overall. Your planetary ruler, the emotional Cancer moon, is forming a connection to a difficult Mars in your identity sector. You can feel lethargic, uninspired, and unmotivated at this time. It�s best to use a day like this to step away from your usual work routine, get into nature, or seek out some alone time to reset. New ideas can have room to come in when you are able to release stress.");
			
			
	
	
	public category4() {
		Timer timer = new Timer(500,this);
		timer.start();
	frame.setLayout(new BorderLayout());
	frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	frame.setSize(1000,600);
	frame.setVisible(true);
	
	txt.setBackground(Color.black);
	txt.setBounds(00,100,100,500);

	
	txtarea.setBounds(400,50,400,600);
	txtarea.setBackground(Color.black);
	txtarea.setForeground(Color.white);
	txtarea.setFont(new Font("Times New Roman",Font.PLAIN,17));
	txtarea.setLineWrap(true);
	txtarea.setWrapStyleWord(true);
	
	txt.add(txtarea);
	
	frame.add(txt, BorderLayout.EAST);
	


	frame.add(new heart(), BorderLayout.CENTER);
	JButton back = new JButton("BACK");
	paint.setBounds(200,500,200,300);
	paint.setOpaque(false);
	paint.add(back);
	frame.add(paint, BorderLayout.SOUTH);
	
	back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				frame.dispose();
				new Page2();
				
			}
		});	
	

	
	
	
	
	
	
	
	
	
	
	
	}
	
}
