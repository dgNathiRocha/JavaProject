package fortunecategories;
import starter.Page2;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class category10 extends Page2 implements ActionListener{
	
	JFrame frame = new JFrame("Fortune Teller");
	JPanel txt = new JPanel();
	JPanel paint = new JPanel();
	JTextArea txtarea = new JTextArea(
			 "Daily Love\n"
			+ "You know what you want and you're not afraid to go after it, Capricorn. Single or attached, today's transformative trine between the sun in your romantic fifth house of love and hypnotic Pluto in your sign will invigorate you with a lusty synergy of courage. This, of course, will reflect on your love life. So, be mindful of the way you're using your power, as the essence of Pluto can be secretly manipulative when crossed. Keep in mind, the moon will continue traveling alongside red-hot Mars via your committed seventh house of significant others, highlighting your lover's emotional needs. Again, use this insight wisely. Karma is real.\r\n"
					 +
					 "Daily Work\n"+
"Working independently can serve you well today. Organize all of the work you can do alone, and schedule out the time to accomplish it. You can feel ultra-focused with Mercury, the planet of thought, in its domicile in your sixth house of work. Mercury is also sending supportive energy to stable Saturn in Aquarius in your money sector. Slow and steady wins the race for you today. Take the work as it comes, dear Capricorn.");
			
			
	
	
	public category10() {
		Timer timer = new Timer(500,this);
		timer.start();
	frame.setLayout(new BorderLayout());
	frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	frame.setSize(1000,600);
	frame.setVisible(true);
	
	txt.setBackground(Color.black);
	txt.setBounds(00,100,100,500);

	
	txtarea.setBounds(400,50,400,600);
	txtarea.setBackground(Color.black);
	txtarea.setForeground(Color.white);
	txtarea.setFont(new Font("Times New Roman",Font.PLAIN,17));
	txtarea.setLineWrap(true);
	txtarea.setWrapStyleWord(true);
	
	txt.add(txtarea);
	
	frame.add(txt, BorderLayout.EAST);
	


	frame.add(new heart(), BorderLayout.CENTER);
	JButton back = new JButton("BACK");
	paint.setBounds(200,500,200,300);
	paint.setOpaque(false);
	paint.add(back);
	frame.add(paint, BorderLayout.SOUTH);
	
	back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				frame.dispose();
				new Page2();
				
			}
		});	
	

	
	
	
	
	
	
	
	
	
	
	
	}
	
}
