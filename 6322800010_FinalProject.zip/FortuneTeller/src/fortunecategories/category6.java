package fortunecategories;
import starter.Page2;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class category6 extends Page2 implements ActionListener{
	
	JFrame frame = new JFrame("Fortune Teller");
	JPanel txt = new JPanel();
	JPanel paint = new JPanel();
	JTextArea txtarea = new JTextArea(
			 "Daily Love\n"
			+ "Both your planetary rulers, Mercury and Venus, are currently transiting your bossy tenth house of authority, career, and reputation in the world. This is bringing your attention to themes surrounding finances and your professional life. More importantly, however, today's smoldering trine between the sun in your expansive ninth house of adventure and transformative Pluto via your romantic fifth house of passion ignites a fire in your heart that could potentially take you on a new journey of love, Virgo. The moon's conjunction with sizzling Mars adds a layer of zest, courage, and strength to the mix�so, ready or not, it's time to let your passions be your guide.\r\n"
					 +
					 "Daily Work\n"+
"Dear Virgo, your meticulous nature is paying off at this time. As the most accurate and detail-oriented sign, this has been your super power in furthering your career. Your professional life requires focus and you can feel as if you are in a million different conversations. Take it one meeting at a time. All of the Gemini energy, in your tenth house of career, is positively impacting hardworking Saturn in Aquarius. You may feel busy, but it is for a reason and it�s all for your professional growth.");
			
			
	
	
	public category6() {
		Timer timer = new Timer(500,this);
		timer.start();
	frame.setLayout(new BorderLayout());
	frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	frame.setSize(1000,600);
	frame.setVisible(true);
	
	txt.setBackground(Color.black);
	txt.setBounds(00,100,100,500);

	
	txtarea.setBounds(400,50,400,600);
	txtarea.setBackground(Color.black);
	txtarea.setForeground(Color.white);
	txtarea.setFont(new Font("Times New Roman",Font.PLAIN,17));
	txtarea.setLineWrap(true);
	txtarea.setWrapStyleWord(true);
	
	txt.add(txtarea);
	
	frame.add(txt, BorderLayout.EAST);
	


	frame.add(new heart(), BorderLayout.CENTER);
	JButton back = new JButton("BACK");
	paint.setBounds(200,500,200,300);
	paint.setOpaque(false);
	paint.add(back);
	frame.add(paint, BorderLayout.SOUTH);
	
	back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				frame.dispose();
				new Page2();
				
			}
		});	
	
	
	
	
	
	
	
	
	
	
	
	}
	
}
