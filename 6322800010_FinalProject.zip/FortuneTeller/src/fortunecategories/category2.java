package fortunecategories;

import java.awt.BorderLayout;

import javax.swing.*;

import java.awt.*; import java.awt.event.*;
import starter.Page2;
public class category2 extends Page2 implements ActionListener {
	
	
		
		
		JFrame frame = new JFrame("Fortune Teller");
		JPanel txt = new JPanel();
		JPanel paint = new JPanel();
		
		JTextArea txtarea = new JTextArea(
				 "Daily Love\n"
				+ "Step into your power, Taurus. You're in the midst of a spiritual metamorphosis and today's trine between the sun in your sign and transformative Pluto in your expansive ninth house of adventure marks the beginning of a significant journey. And despite whether you're single or attached, the immense amount of change you're in the process of experiencing isn't hard to miss. Today's moon will also conjunct red-hot Mars, heightening everything from your emotions to your red-hot passions. This energy is coming to life via your experimental eleventh house of associations, friendship, and sense of belonging in the world. Look towards the future with confidence.\r\n"
						 +
						 "Daily Work\n"+
	"Dear Taurus, the planets are empowering your belief in yourself. This has been a time of major personal growth and career transformation. The Taurus sun is forming an energizing aspect with authoritative Pluto in Capricorn. Authenticity, leadership, and wisdom are professional attributes that this planetary alignment is encouraging you. In order to earn a managerial title, sometimes we have to be the change first. Release old limiting beliefs, and know that you can achieve anything you set your mind to.");
				
				
		
		
		public category2() {
			Timer timer = new Timer(500,this);
			timer.start();
		frame.setLayout(new BorderLayout());
		frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		frame.setSize(1000,600);
		frame.setVisible(true);
		
		txt.setBackground(Color.black);
		txt.setBounds(00,100,100,500);

		
		txtarea.setBounds(400,50,400,600);
		txtarea.setBackground(Color.black);
		txtarea.setForeground(Color.white);
		txtarea.setFont(new Font("Times New Roman",Font.PLAIN,17));
		txtarea.setLineWrap(true);
		txtarea.setWrapStyleWord(true);
		
		txt.add(txtarea);
		
		frame.add(txt, BorderLayout.EAST);
		
		
		
		frame.add(new heart(), BorderLayout.CENTER);
		JButton back = new JButton("BACK");
		paint.setBounds(200,500,200,300);
		paint.setOpaque(false);
		paint.add(back);
		frame.add(paint, BorderLayout.SOUTH);
		
		back.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent ae) {
					frame.dispose();
					new Page2();
					
				}
			});	
}
		
			
		}