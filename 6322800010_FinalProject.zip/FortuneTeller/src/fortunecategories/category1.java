package fortunecategories;
import starter.Page2;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class category1 extends Page2 implements ActionListener{
	
	JFrame frame = new JFrame("Fortune Teller");
	JPanel txt = new JPanel();
	JPanel paint = new JPanel();
	JButton back = new JButton("BACK");
	JTextArea txtarea = new JTextArea(
			 "Daily Love\n"
			+ "Expressing your emotions could seem triggering today, but the only way out is through, Aries. Today's moon will touch down on your domestic fourth house of home and early foundation, emotionally binding you to matters of the family, and household. So, tell your cutie you're staying in tonight. Keep in mind, themes surrounding your innermost feelings, and general sense of stability could also come up for review during this time. But Luna's square with the wounded healer, Chiron, could help you resolve some past wounds in the process. Warning: Try to find an emotional outlet, as the moon will be sitting closely with your hot-headed planetary ruler, Mars.\r\n"
					 +
					 "Daily Work\n"+
"This is a powerful day for you financially, dear Aries. The lucrative Taurus sun is in your second house of earned income and money, forming an auspicious connection with Pluto in Capricorn in your career sector. This is empowering you to take on a leadership role, or more responsibility. Both planetary energies are in earth signs, which signals grounding and manifestation. With more tasks comes extra money. Embrace this change for the better and stand in your power.");
			
			
	
	
	public category1() {
		Timer timer = new Timer(500,this);
		timer.start();
	frame.setLayout(new BorderLayout());
	frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	frame.setSize(1000,600);
	frame.setVisible(true);
	
	txt.setBackground(Color.black);
	txt.setBounds(00,100,100,500);

	
	txtarea.setBounds(400,50,400,600);
	txtarea.setBackground(Color.black);
	txtarea.setForeground(Color.white);
	txtarea.setFont(new Font("Times New Roman",Font.PLAIN,17));
	txtarea.setLineWrap(true);
	txtarea.setWrapStyleWord(true);
	
	txt.add(txtarea);
	
	frame.add(txt, BorderLayout.EAST);
	

	
	
	frame.add(new heart(), BorderLayout.CENTER);
	
	paint.setBounds(200,500,200,300);
	paint.setOpaque(false);
	paint.add(back);
	frame.add(paint, BorderLayout.SOUTH);
	
	back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				frame.dispose();
				new Page2();
				
			}
		});	
	
	
	
	}
	
	
}
