package fortunecategories;
import starter.Page2;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class category11 extends Page2 implements ActionListener{
	JFrame frame = new JFrame("Fortune Teller");
	JPanel txt = new JPanel();
	JPanel paint = new JPanel();
	JTextArea txtarea = new JTextArea(
			 "Daily Love\n"
			+ "Perhaps a raincheck, Aquarius? Today's transformative trine between the sun in your cozy fourth house of home, family, and emotional foundations, and hypnotic Pluto via your secretive twelfth house of closure, dreams, and unconscious patterns, could potentially trigger a catharsis of sorts. So, if you're feeling more introspective than usual, or perhaps dealing with some stuff in the home front, don't hesitate to take a step back. Besides, you have to take care of you before you can offer your cup of love to anyone else. The moon will also sit alongside Mars in your responsible sixth house, so tend to your due diligence.\r\n"
					 +
					 "Daily Work\n"+
"Dear Aquarius, your creative projects are going in the right direction for you today. This is thanks to the positive energy of Venus in its joy in Gemini in your fifth house of projects, sending supportive energy to your planetary ruler, Saturn. This energy is allowing you to find joy and a renewed sense of fulfillment in what you do for work. You can even mix your social life with your career at this time.");
			
			
	
	
	public category11() {
		Timer timer = new Timer(500,this);
		timer.start();
	frame.setLayout(new BorderLayout());
	frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	frame.setSize(1000,600);
	frame.setVisible(true);
	
	txt.setBackground(Color.black);
	txt.setBounds(00,100,100,500);

	
	txtarea.setBounds(400,50,400,600);
	txtarea.setBackground(Color.black);
	txtarea.setForeground(Color.white);
	txtarea.setFont(new Font("Times New Roman",Font.PLAIN,17));
	txtarea.setLineWrap(true);
	txtarea.setWrapStyleWord(true);
	
	txt.add(txtarea);
	
	frame.add(txt, BorderLayout.EAST);
	


	frame.add(new heart(), BorderLayout.CENTER);
	JButton back = new JButton("BACK");
	paint.setBounds(200,500,200,300);
	paint.setOpaque(false);
	paint.add(back);
	frame.add(paint, BorderLayout.SOUTH);
	
	back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				frame.dispose();
				new Page2();
				
			}
		});	
	

	
	
	
	
	
	
	
	
	
	
	
	}
	
}
