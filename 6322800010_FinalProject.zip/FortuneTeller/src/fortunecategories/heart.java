package fortunecategories;
import javax.swing.*;
import java.awt.*;

public class heart extends JPanel {
	double a = 90.5;
	private int x = (int) a;
	
	private int y = 75;
	private int width = 150;
	
	public heart() {
	
	}
	public void paint(java.awt.Graphics g){
		
		        super.paintComponent(g);
		
		 
		
		     
		
		 
		
		        
		
		// oval 1
		
		        g.setColor(Color.pink);
		
		        g.fillOval(x, y, width, 150);
		
		 
		
		 
		
		// oval2 same size
		
		        g.fillOval(235, y, width, 150);
		
		 
		
		//tangent
		
		        g.drawLine(96, 181, 238, 375);
		
		 
		
		//tangent 2
		
		        g.drawLine(380, 181, 238, 375);
		
		 
		
		//triangle
		
		g.setColor(Color.red);
		
		int[] xPoints = {96,380,238};
		
		int[] yPoints = {181,181,375};
		
		g.fillPolygon(xPoints, yPoints, 3);
		
		g.setColor(Color.blue);
		g.drawString("Your Fourtune", 200, 400);
		
		  }

		
	}
			  



